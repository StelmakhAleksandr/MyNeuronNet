#pragma once
class Settings
{
public:
	Settings();
	~Settings();
};

