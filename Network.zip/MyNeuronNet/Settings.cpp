#include "Settings.h"



Settings::Settings()
{
}


Settings::~Settings()
{
}
